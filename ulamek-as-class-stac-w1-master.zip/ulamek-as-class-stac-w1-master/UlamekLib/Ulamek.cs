﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UlamekLib
{
    public class Ulamek
    {
        private readonly long licznik = 0;
        private readonly long mianownik = 1;

        public long Licznik => licznik;
        /*
        {
            get
            {
                return licznik;
            }
        }
        */
        public long Mianownik => mianownik;

        public Ulamek(long licznik, long mianownik, bool upraszczanie= true) // konstruktor
        {

            if (mianownik == 0)
                throw new DivideByZeroException("mianownik nie może być 0");
            if (licznik * mianownik > 0)
            {
                licznik = Math.Abs(licznik);
                mianownik = Math.Abs(mianownik);
            }
            else
            {
                licznik = (-1) * Math.Abs(licznik);
                mianownik = Math.Abs(mianownik);
            }
            // upraszczanie
            if (upraszczanie)
            {
                long nwd = NWD(licznik, mianownik);
                licznik /= nwd;
                mianownik /= nwd;
            }


            this.licznik = licznik;
            this.mianownik = mianownik;

        }

       
        
        // wyznacza nwd  podanych parametrow
        private long NWD (long a, long b )
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            long tmp;
            while (b != 0)
            {
                tmp = a % b;
                a = b;
                b = tmp;
            }
            return a;
           
        }

        public Ulamek() : this(0 ,1) { }

        public Ulamek( long liczba ) : this(liczba, 1) { }

        public Ulamek( string napis )
        {
            //to do
            throw new NotImplementedException();
        }

        public Ulamek( double liczba )
        {
            //to do
            throw new NotImplementedException();
        }

        public override string ToString() //=> $"{licznik}/{mianownik}";
        {
            return $"{licznik}/{mianownik}";
        }

    }
}
