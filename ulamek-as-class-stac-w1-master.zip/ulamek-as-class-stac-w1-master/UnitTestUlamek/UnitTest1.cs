﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UlamekLib;


namespace UnitTestUlamek
{
    [TestClass] //klasa ktora wezmie udzial w procesie testowania kodu
    public class UnitTest1
    {
        [TestMethod]
        public void KonstruktorDomyslny_LicznikZero_MianownikJeden() // nie zwraca wyniku (void) 1.co testujemy , przy jakich warunkach i do czego
        {
            //AAA
            //Arange
            Ulamek u = new Ulamek();
            // Act
            //Assert, weryfikuje poprwnosc rzeczy, sprawdza
            Assert.AreEqual(0, u.Licznik);
            Assert.AreEqual(1, u.Mianownik);
        }

        [DataTestMethod]
        [DataRow(-1)]
        [DataRow(0)]// adnotacje. to sa metainformacje ktore sa potrzebene framework ktory zarzadza testami
        [DataRow(7)]


        public void KonstruktorJednoargumentowy_ArgumentWLiczniku(long l, long m)
        {
            Ulamek u = new Ulamek(l, m);
            Assert.AreEqual(Math.Abs(l), Math.Abs(u.Licznik));
            Assert.AreEqual(1, u.Mianownik);
        }

        [DataTestMethod]
        [DataRow(2, 5)]
        [DataRow(-2, 5)]// adnotacje. to sa metainformacje ktore sa potrzebene framework ktory zarzadza testami
        [DataRow(2, -5)]
        [DataRow(-2, -5)]


        public void KonstruktorDwuargumentowy_ZnakWLiczniku(long l, long m) // za_ czyli wartosc ktora sprawdzam
        {
            Ulamek u = new Ulamek(l, m);
            Assert.AreEqual(Math.Abs(l), Math.Abs(u.Licznik));
            Assert.AreEqual(Math.Abs(m), Math.Abs(u.Mianownik));
            Assert.IsTrue(u.Mianownik > 0);
            Assert.AreEqual(Math.Sign(l * m), Math.Sign(u.Licznik));
        }
        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void KonstruktorDwuargumentowy_Wyjatek_DevideByZero()
        {
            Ulamek u = new Ulamek(1, 0);
            //Assert.ThrowsException()
        }


        [DataTestMethod]
        [DataRow(8, 12, 2, 3)]
        [DataRow(-2, -4, -1, 2)]// adnotacje. to sa metainformacje ktore sa potrzebene framework ktory zarzadza testami
        [DataRow(2, -8, -1, 4)]
        [DataRow(-24, -6, 4, 1)]

        public void KonstruktorDwuargumentowy_Upraszczanie(long l, long m, long ul, long um)
        // za_ czyli wartosc ktora sprawdzam
        {
            Ulamek u = new Ulamek(l, m);
            Assert.AreEqual(ul, u.Licznik);
            Assert.AreEqual(um, u.Mianownik);
        }
    }
}
